package com.qc.function;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.qc.request.AgentService;

public class PutAgentService implements RequestHandler<AgentService, Object>{

	@Override
	public Object handleRequest(AgentService agentService, Context arg1) {
		String isSuccess = "success";
		try {
			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.defaultClient();
			DynamoDBMapper mapper = new DynamoDBMapper(client);	
			if(!(agentService.getAgentServiceId()!=null&&!agentService.getAgentId().isEmpty())) {
				System.out.println("creating new agent-service.");
				LocalDateTime now = LocalDateTime.now();  
				DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");  
				String formatDateTime = now.format(format);  
				agentService.setCreatedTime(formatDateTime);
				mapper.save(agentService);			
			}else {
				System.out.println("updating into agent-service.");
				DynamoDBMapperConfig dynamoDBMapperConfig = new DynamoDBMapperConfig.Builder()
						  .withConsistentReads(DynamoDBMapperConfig.ConsistentReads.CONSISTENT)
						  .withSaveBehavior(DynamoDBMapperConfig.SaveBehavior.UPDATE)
						  .build();
				mapper.save(agentService,dynamoDBMapperConfig);
			}
			System.out.println(agentService.toString());
		}catch(Exception e) {
			e.printStackTrace();
			isSuccess = "failure";
		}
		return isSuccess;
	}



}
